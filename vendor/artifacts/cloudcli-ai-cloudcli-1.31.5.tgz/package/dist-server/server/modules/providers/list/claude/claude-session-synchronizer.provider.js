import os from 'node:os';
import path from 'node:path';
import { sessionsDb } from '../../../../modules/database/index.js';
import { buildLookupMap, extractFirstValidJsonlData, findFilesRecursivelyCreatedAfter, normalizeSessionName, readFileTimestamps, } from '../../../../shared/utils.js';
/**
 * Session indexer for Claude transcript artifacts.
 */
export class ClaudeSessionSynchronizer {
    provider = 'claude';
    claudeHome = path.join(os.homedir(), '.claude');
    /**
     * Scans ~/.claude/projects and upserts discovered sessions into DB.
     */
    async synchronize(since) {
        const nameMap = await buildLookupMap(path.join(this.claudeHome, 'history.jsonl'), 'sessionId', 'display');
        const files = await findFilesRecursivelyCreatedAfter(path.join(this.claudeHome, 'projects'), '.jsonl', since ?? null);
        let processed = 0;
        for (const filePath of files) {
            const parsed = await this.processSessionFile(filePath, nameMap);
            if (!parsed) {
                continue;
            }
            const timestamps = await readFileTimestamps(filePath);
            sessionsDb.createSession(parsed.sessionId, this.provider, parsed.projectPath, parsed.sessionName, timestamps.createdAt, timestamps.updatedAt, filePath);
            processed += 1;
        }
        return processed;
    }
    /**
     * Parses and upserts one Claude session JSONL file.
     */
    async synchronizeFile(filePath) {
        if (!filePath.endsWith('.jsonl')) {
            return null;
        }
        const nameMap = await buildLookupMap(path.join(this.claudeHome, 'history.jsonl'), 'sessionId', 'display');
        const parsed = await this.processSessionFile(filePath, nameMap);
        if (!parsed) {
            return null;
        }
        const timestamps = await readFileTimestamps(filePath);
        return sessionsDb.createSession(parsed.sessionId, this.provider, parsed.projectPath, parsed.sessionName, timestamps.createdAt, timestamps.updatedAt, filePath);
    }
    /**
     * Extracts session metadata from one Claude JSONL session file.
     */
    async processSessionFile(filePath, nameMap) {
        return extractFirstValidJsonlData(filePath, (rawData) => {
            const data = rawData;
            const sessionId = typeof data.sessionId === 'string' ? data.sessionId : undefined;
            const projectPath = typeof data.cwd === 'string' ? data.cwd : undefined;
            if (!sessionId || !projectPath) {
                return null;
            }
            return {
                sessionId,
                projectPath,
                sessionName: normalizeSessionName(nameMap.get(sessionId), 'Untitled Claude Session'),
            };
        });
    }
}
//# sourceMappingURL=claude-session-synchronizer.provider.js.map